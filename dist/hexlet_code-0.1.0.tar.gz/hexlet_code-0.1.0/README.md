### Hexlet tests and linter status:
[![Actions Status](https://github.com/lisa-gold/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/lisa-gold/python-project-49/actions)

### CodeClimate Badge
[![Maintainability](https://api.codeclimate.com/v1/badges/3cefe61c523850122157/maintainability)](https://codeclimate.com/github/lisa-gold/python-project-49/maintainability)

### Record - brain-even
https://asciinema.org/a/cKBLPg30BMvG3vXlYB53VQqKz

### Record - brain-calc
https://asciinema.org/a/tRNlD2u6CWyHYHD5t22APbBp7

### Record - brain-gcd
https://asciinema.org/a/yy0kbAZE8xpLMpDPWbFD0bzy5