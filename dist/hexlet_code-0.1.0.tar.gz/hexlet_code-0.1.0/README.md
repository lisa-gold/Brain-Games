### Hexlet tests and linter status:
[![Actions Status](https://github.com/lisa-gold/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/lisa-gold/python-project-49/actions)

### CodeClimate Badge
[![Maintainability](https://api.codeclimate.com/v1/badges/3cefe61c523850122157/maintainability)](https://codeclimate.com/github/lisa-gold/python-project-49/maintainability)
